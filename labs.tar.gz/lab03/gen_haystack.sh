#!/bin/bash

rm -f ./haystack.txt
lim=$(( ( RANDOM % 100000 )  + 1 ))

for (( c=0; c<$lim; c++ )); do
	echo haystack >> haystack.txt
done

echo niddle >> haystack.txt

for (( c=0; c<$lim; c++ )); do
	echo haystack >> haystack.txt
done