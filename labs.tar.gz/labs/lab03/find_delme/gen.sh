#!/bin/bash

rs=""
function random_str()
{
	# $1 = the length of the string
	rs=`head /dev/urandom | tr -dc A-Za-z0-9 | head -c$1`
}

function newfile()
{
	# $1 = prefix of the new generated file
	random_str 4
	touch $1$rs.jpg
}

num=1000

for i in `seq $num`;do
	if [[ $(( $RANDOM % 10 )) = 9 ]]; then
		newfile delme_
	else
		newfile
	fi
done

