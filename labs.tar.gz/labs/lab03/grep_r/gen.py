import os, random, string

def rstr(n):
	return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(n))

def rmd(n):
	for i in range(n):
		os.mkdir(rstr(8))

lev_lim = 5
dir_lim = 5
def gen(d, lev):
	if lev >= lev_lim:
		return
	
	if d != "":
		os.chdir(d)
	rmd(dir_lim)

	li = os.listdir()
	lev += 1

	for i in li:
		if os.path.isdir(i):
			gen(i, lev)
	os.chdir("..")

def main():
	gen("", 0)

if __name__ == '__main__':
	main()