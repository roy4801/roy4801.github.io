#!/bin/bash
rs=""
function random_str()
{
	# $1 = the length of the string
	rs=`head /dev/urandom | tr -dc A-Za-z0-9 | head -c$1`
}

for i in {1..100}; do
	random_str 10
	echo $rs >> sort_1.txt
done


for i in {1..100}; do
	echo $(( RANDOM % 10000 )) >> sort_2.txt
done