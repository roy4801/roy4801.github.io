#!/bin/bash

rs=""
function random_str()
{
	# $1 = the length of the string
	rs=`head /dev/urandom | tr -dc A-Za-z0-9 | head -c$1`
}

rm -f wc_l.txt wc_w.txt

num=878787
for (( i=0; i<$num; i++ )); do
	random_str 4
	echo $rs >> wc_l.txt
done

num=1571
for (( i=0; i<$num; i++ )); do
	random_str 4
	printf $rs" " >> wc_w.txt
done